package bridge.ejercicio1ConBridge;

public interface Arquitectura {
	public void programar();
	
}
