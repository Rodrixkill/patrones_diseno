package bridge.ejercicio1ConBridge;

public class X64 implements Arquitectura {

	@Override
	public void programar() {
		System.out.println("programando con una arquitectura de 64 bits");
	}

}
