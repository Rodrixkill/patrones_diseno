package bridge.ejercicio1ConBridge;

public interface IPlataforma {
	
	public void plataforma();

}
