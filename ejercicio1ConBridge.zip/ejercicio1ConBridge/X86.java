package bridge.ejercicio1ConBridge;

public class X86 implements Arquitectura {

	@Override
	public void programar() {
		System.out.println("programando con una arquitectura de 32 bits");


	}

}
