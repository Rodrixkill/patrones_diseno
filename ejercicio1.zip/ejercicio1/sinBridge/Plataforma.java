package bridge.ejercicio1.sinBridge;

public interface Plataforma {
	
	public void plataforma();
	public void arquitecturaX86();
	public void arquitecturaX64();

}
